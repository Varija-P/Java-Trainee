package myProject;

import java.util.Scanner;

public class switch_deptname_ex {

	public static void main(String[] args) {
		Scanner c=new Scanner(System.in);
		// TODO Auto-generated method stub
		int course_code;
		System.out.println("Enter Course code:");
		course_code=c.nextInt();
		
		switch(course_code)
		{
			case 101:
				System.out.println("DEPT is: CSE");
				break;
			case 102:
				System.out.println("DEPT is: EEE");
				break;
			case 103:
				System.out.println("DEPT is: MECH");
				break;
			case 104:
				System.out.println("DEPT is: CIVIL");
				break;
			default:
				System.out.println("INVALID COURSE CODE");
				break;
			
		}

	}

}
