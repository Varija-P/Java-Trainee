package myProject;

public class hello_world {

}
