package myProject;

public class switch_ex {
	public static void main(String[] args)
	{
		int bas_sal,hra;
		bas_sal=3000;
		switch(bas_sal)
		{
		case 1500:
			hra=bas_sal*20/100;
			System.out.println("Basic salary:"+bas_sal+" hra:" +hra);
			break;
		case 2500:
			hra=bas_sal*25/100;
			System.out.println("Basic salary:"+bas_sal+" hra:" +hra);
			break;
		case 4500:
			hra=bas_sal*28/100;
			System.out.println("Basic salary:"+bas_sal+" hra:" +hra);
			break;
		default:
			hra=bas_sal*10/100;
			System.out.println("Basic salary:"+bas_sal+" hra:" +hra);
			break;
			
		}
	}

}
