package myProject;

import java.util.Scanner;

public class stud_marks_ex {

	public static void main(String[] args) {
		
		// 
		Scanner s=new Scanner(System.in);
		String stud_name,reg_no,dob,dep,res,grade;
		Float mark1,mark2,mark3;
		
		System.out.println("Enter Student Name:");
		stud_name=s.next();
		System.out.println("Enter Student RegNo:");
		reg_no=s.next();
		System.out.println("Enter Student DateOfBirth:");
		dob=s.next();
		System.out.println("Enter mark 1:");
		mark1=s.nextFloat();
		System.out.println("Enter mark 2:");
		mark2=s.nextFloat();
		System.out.println("Enter mark 3:");
		mark3=s.nextFloat();
		System.out.println("Enter Department name:");
		dep=s.next();
		float total=mark1+mark2+mark3;
		
		System.out.println("==========================");
		System.out.println("STUDENT MARKS LIST ");
		System.out.println("==========================");
		System.out.println("Student Name:" +stud_name+   "\t DOB:"+dob);
		System.out.println("REG NO:"+reg_no+ "\t \t DEP:"+dep);
		System.out.println("Mark1:"+mark1);
		System.out.println("Mark2:"+mark2);
		System.out.println("Mark3:"+mark3);
		System.out.println("==========================");
		System.out.println("Total Mark:"+total+  "\t AverageMark:"+(total/3));
		
		
		if(mark1>35 && mark2>35 && mark3>35)
			System.out.print("Result:PASS \t");
		else
			System.out.print("Result:FAIL \t");
		
		if(total>275)
			System.out.print("GRADE : A+");
		
		else if(total>200)
			System.out.print("GRADE: A");
		
		else if(total>150 && total<200)
			System.out.print("GRADE: B");
		
		else
			System.out.print("GRADE : C");
		}
		
		
	}


