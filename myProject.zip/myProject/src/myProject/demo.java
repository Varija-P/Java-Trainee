package myProject;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		int course_id;
		String Course_Name;
		course_id=1001;
		Course_Name="Java full stack";
       System.out.println("Course id is:" + course_id);
		System.out.println("Course name is:" + Course_Name);
	}
	

}
