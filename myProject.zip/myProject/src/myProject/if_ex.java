package myProject;

public class if_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int acc_bal, with_amt;
		acc_bal=10000;
		with_amt=9999;
		if(acc_bal>with_amt)
		{
			System.out.println("transaction successful...");
			acc_bal=acc_bal-with_amt;
			System.out.println("available balance:" +acc_bal);
		}
		else if(acc_bal==with_amt)
		{
			System.out.println("sorry..min balance must be 1000/-");
		}
		else
			System.out.println("Insufficiet balance");
	}

}
